//+------------------------------------------------------------------+
//|                                              Sample DLL for MQL4 |
//|                      Copyright � 2004, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once

#define WIN32_LEAN_AND_MEAN      // Exclude rarely-used stuff from Windows headers
#include <windows.h>
//+------------------------------------------------------------------+
